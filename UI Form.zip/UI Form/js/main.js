
$(function () {

  'use strict';

  $('.sign-input input').on('focusout', function () {

    if ($(this).val() != '') {

      $(this).parent().addClass('isFilled');

    } else {

      $(this).parent().removeClass('isFilled');

    }

  });

});
